import { useEffect, useMemo, useState } from "react";
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
  type User,
} from "firebase/auth";
import {
  AlertTriangle,
  BarChart3,
  CalendarDays,
  Check,
  ChevronRight,
  Clock3,
  Loader2,
  LogOut,
  Menu,
  Plus,
  Scissors,
  ShieldCheck,
  Trash2,
  Users,
  X,
} from "lucide-react";
import { Link } from "wouter";
import { firebaseAuth, firebaseConfigured } from "@/lib/firebase";
import { trpc } from "@/lib/trpc";
import {
  buildSlots,
  businessDateIso,
  currency,
  dateLabel,
  defaultServices,
  safeWhatsApp,
  type Service,
} from "@shared/domain";

type Tab = "agenda" | "financas" | "servicos" | "bloqueios" | "equipe";
type AppointmentRow = Record<string, unknown> & {
  id: string;
  date: string;
  startTime: string;
  endTime: string;
  status: "Agendado" | "Concluído" | "Cancelado" | "Faltou";
  customerName: string;
  mainServiceName: string;
  price?: number;
  paidAmount?: number;
};

type DashboardData = {
  appointments: Array<Record<string, unknown> & { id: string }>;
  blocks: Array<Record<string, string | null>>;
  revenue: number;
};

const isoToday = () => businessDateIso();

function AuthLoading() {
  return (
    <div className="admin-login">
      <div className="login-panel" aria-live="polite">
        <Link href="/" className="login-brand">
          <span className="monogram">SN</span>
          <span>Suzanny <em>Nail Designer</em></span>
        </Link>
        <p className="eyebrow gold">ÁREA RESTRITA</p>
        <h1>Preparando sua agenda.</h1>
        <p className="login-copy">Estamos verificando seu acesso com segurança.</p>
        <div className="notice"><Loader2 className="spin" size={16} /> Carregando acesso…</div>
      </div>
      <LoginAside />
    </div>
  );
}

function LoginAside() {
  return (
    <div className="login-aside">
      <p className="eyebrow gold">PAINEL DA CHEFE</p>
      <h2>Tempo bem cuidado é tempo que rende.</h2>
      <div className="aside-rule" />
      <p>Agenda, equipe, serviços e retornos em uma única visão — com o mesmo cuidado que existe em cada atendimento.</p>
    </div>
  );
}

function ConfigurationGate({ serverReady }: { serverReady: boolean }) {
  const message = !firebaseConfigured
    ? "Este painel ainda não recebeu as configurações públicas do Firebase."
    : !serverReady
      ? "O servidor não conseguiu acessar o Firestore com as credenciais configuradas."
      : "O Firebase ainda não está pronto para este painel.";

  return (
    <div className="admin-login">
      <div className="login-panel">
        <Link href="/" className="login-brand">
          <span className="monogram">SN</span>
          <span>Suzanny <em>Nail Designer</em></span>
        </Link>
        <p className="eyebrow gold">ACESSO EM CONFIGURAÇÃO</p>
        <h1>Agenda protegida.</h1>
        <p className="login-copy">{message} Para evitar acessos incompletos e reservas sem sincronização, o login fica bloqueado até a conexão ser finalizada.</p>
        <div className="notice error">A proprietária precisa concluir a configuração indicada em <strong>FIREBASE_SETUP.md</strong>. Nenhuma senha ou contato deve ser cadastrado nesta tela.</div>
        <Link href="/" className="text-button">Voltar para a vitrine</Link>
      </div>
      <LoginAside />
    </div>
  );
}

function formatAuthError(caught: unknown) {
  const code = typeof caught === "object" && caught !== null && "code" in caught
    ? String(caught.code)
    : "";
  const known: Record<string, string> = {
    "auth/invalid-credential": "E-mail ou senha incorretos.",
    "auth/invalid-email": "Informe um e-mail válido.",
    "auth/user-disabled": "Este acesso foi desativado.",
    "auth/email-already-in-use": "Este e-mail já possui uma senha. Entre com seus dados.",
    "auth/weak-password": "A senha precisa ter pelo menos 6 caracteres.",
    "auth/network-request-failed": "Não foi possível alcançar o serviço de acesso. Verifique sua conexão.",
    "auth/too-many-requests": "Muitas tentativas. Aguarde alguns instantes antes de tentar novamente.",
  };
  if (known[code]) return known[code];
  return caught instanceof Error
    ? caught.message.replace(/^Firebase:\s*/i, "")
    : "Não foi possível concluir o acesso. Tente novamente.";
}

function AuthGate({ onUser }: { onUser: (user: User | null) => void }) {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const invite = trpc.invite.check.useQuery({ email }, { enabled: false, retry: false });

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!firebaseAuth) return;
    setBusy(true);
    setError("");

    try {
      if (mode === "signup") {
        const normalizedEmail = email.trim().toLowerCase();
        const result = await invite.refetch();
        if (!result.data?.allowed) {
          throw new Error("Este e-mail ainda não foi autorizado pela Suzanny. Peça para ele ser adicionado em Equipe antes de criar sua senha.");
        }
        const credential = await createUserWithEmailAndPassword(firebaseAuth, normalizedEmail, password);
        onUser(credential.user);
      } else {
        const credential = await signInWithEmailAndPassword(firebaseAuth, email.trim(), password);
        onUser(credential.user);
      }
    } catch (caught) {
      setError(formatAuthError(caught));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="admin-login">
      <div className="login-panel">
        <Link href="/" className="login-brand">
          <span className="monogram">SN</span>
          <span>Suzanny <em>Nail Designer</em></span>
        </Link>
        <p className="eyebrow gold">ÁREA RESTRITA</p>
        <h1>Agenda sob controle.</h1>
        <p className="login-copy">Entre com o e-mail autorizado pela Suzanny para cuidar da agenda com segurança.</p>
        <form onSubmit={submit} className="login-form">
          <label className="input-label">E-mail
            <input type="email" autoComplete="email" value={email} onChange={event => setEmail(event.target.value)} required placeholder="voce@exemplo.com" />
          </label>
          <label className="input-label">Senha
            <input type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} value={password} onChange={event => setPassword(event.target.value)} required minLength={6} placeholder="mínimo de 6 caracteres" />
          </label>
          {error && <div className="notice error" role="alert">{error}</div>}
          <button className="gold-button full" disabled={busy}>
            {busy ? <><Loader2 className="spin" size={17} /> Verificando…</> : mode === "login" ? "Entrar na agenda" : "Criar acesso"}
          </button>
        </form>
        <button className="text-button" type="button" disabled={busy} onClick={() => { setError(""); setMode(current => current === "login" ? "signup" : "login"); }}>
          {mode === "login" ? "Primeiro acesso? Criar senha" : "Já tenho acesso · Entrar"}
        </button>
        <p className="privacy-note"><ShieldCheck size={14} /> Acesso validado também no servidor.</p>
      </div>
      <LoginAside />
    </div>
  );
}

function UnauthorizedGate({ onLogout }: { onLogout: () => Promise<void> }) {
  const [leaving, setLeaving] = useState(false);
  return (
    <div className="admin-login">
      <div className="login-panel">
        <Link href="/" className="login-brand"><span className="monogram">SN</span><span>Suzanny <em>Nail Designer</em></span></Link>
        <p className="eyebrow gold">ACESSO NÃO LIBERADO</p>
        <h1>Conta sem permissão.</h1>
        <p className="login-copy">Seu e-mail foi autenticado, mas ainda não está ativo na equipe. Peça à Suzanny para cadastrá-lo na aba Equipe e tente novamente.</p>
        <button className="gold-button full" disabled={leaving} onClick={async () => { setLeaving(true); await onLogout(); }}>
          <LogOut size={17} /> Sair desta conta
        </button>
      </div>
      <LoginAside />
    </div>
  );
}

export default function Admin() {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const serverStatus = trpc.firebase.status.useQuery(undefined, { retry: false, staleTime: 60_000 });

  useEffect(() => {
    if (!firebaseAuth) {
      setAuthReady(true);
      return;
    }
    return onAuthStateChanged(firebaseAuth, nextUser => {
      setUser(nextUser);
      setAuthReady(true);
    });
  }, []);

  if (!firebaseConfigured) return <ConfigurationGate serverReady={Boolean(serverStatus.data?.ready)} />;
  if (serverStatus.isLoading || !authReady) return <AuthLoading />;
  if (!serverStatus.data?.ready) return <ConfigurationGate serverReady={false} />;
  if (!user) return <AuthGate onUser={setUser} />;
  return <Panel user={user} />;
}

function Panel({ user }: { user: User }) {
  const actor = trpc.staff.me.useQuery(undefined, { retry: false, refetchOnWindowFocus: true });

  async function logout() {
    if (firebaseAuth) await signOut(firebaseAuth);
  }

  if (actor.isLoading) return <AuthLoading />;
  if (actor.isError || !actor.data) return <UnauthorizedGate onLogout={logout} />;
  return <AuthorizedPanel user={user} actor={actor.data} onLogout={logout} />;
}

function AuthorizedPanel({ user, actor, onLogout }: { user: User; actor: { name?: string; role: "admin" | "reception" }; onLogout: () => Promise<void> }) {
  const [tab, setTab] = useState<Tab>("agenda");
  const [date, setDate] = useState(isoToday());
  const [mobileNav, setMobileNav] = useState(false);
  const isAdmin = actor.role === "admin";
  const dashboard = trpc.staff.dashboard.useQuery({ date }, { refetchInterval: 15_000 });
  const appointments = trpc.staff.appointments.useQuery({}, { enabled: isAdmin, refetchInterval: 30_000 });
  const crm = trpc.staff.crm.useQuery(undefined, { enabled: isAdmin, refetchInterval: 30_000 });
  const servicesQuery = trpc.staff.services.useQuery(undefined, { enabled: isAdmin });
  const blocksQuery = trpc.staff.blocks.useQuery(undefined, { enabled: isAdmin });
  const teamQuery = trpc.staff.team.useQuery(undefined, { enabled: isAdmin });
  const statusMutation = trpc.staff.updateStatus.useMutation({ onSuccess: () => { void dashboard.refetch(); void appointments.refetch(); } });
  const saveService = trpc.staff.saveService.useMutation({ onSuccess: () => void servicesQuery.refetch() });
  const deactivateService = trpc.staff.deactivateService.useMutation({ onSuccess: () => void servicesQuery.refetch() });
  const createBlock = trpc.staff.createBlock.useMutation({ onSuccess: () => { void blocksQuery.refetch(); void dashboard.refetch(); } });
  const deleteBlock = trpc.staff.deleteBlock.useMutation({ onSuccess: () => { void blocksQuery.refetch(); void dashboard.refetch(); } });
  const saveTeam = trpc.staff.saveTeamMember.useMutation({ onSuccess: () => void teamQuery.refetch() });
  const removeTeam = trpc.staff.removeTeamMember.useMutation({ onSuccess: () => void teamQuery.refetch() });
  const [serviceForm, setServiceForm] = useState({ id: "service-new", name: "", kind: "main" as "main" | "addon", price: 0, durationMinutes: 60, maintenanceDays: 15, description: "", active: true });
  const [blockForm, setBlockForm] = useState({ date, kind: "period" as "slot" | "period" | "day", startTime: "12:00", endTime: "13:00", reason: "" });
  const [teamForm, setTeamForm] = useState({ email: "", name: "", role: "reception" as "admin" | "reception" });
  const dayAppointments = (dashboard.data?.appointments || []) as AppointmentRow[];
  const occupied = useMemo(() => new Set(dayAppointments.filter(item => item.status !== "Cancelado").flatMap(item => buildSlots(item.startTime, item.endTime))), [dayAppointments]);
  const currentServices = (servicesQuery.data?.length ? servicesQuery.data : defaultServices) as Service[];
  const allAppointments = (appointments.data || []) as AppointmentRow[];
  const last30 = allAppointments.filter(item => new Date(`${item.date}T12:00:00`).getTime() >= Date.now() - 30 * 86_400_000 && (item.status === "Agendado" || item.status === "Concluído"));
  const menu = [{ id: "agenda" as const, label: "Agenda", icon: CalendarDays }, ...(isAdmin ? [{ id: "financas" as const, label: "Finanças & CRM", icon: BarChart3 }, { id: "servicos" as const, label: "Serviços", icon: Scissors }, { id: "bloqueios" as const, label: "Bloqueios", icon: Clock3 }, { id: "equipe" as const, label: "Equipe", icon: Users }] : [])];

  useEffect(() => {
    if (!isAdmin && tab !== "agenda") setTab("agenda");
  }, [isAdmin, tab]);

  return <div className="admin-shell">
    <aside className={`admin-sidebar ${mobileNav ? "open" : ""}`}>
      <div className="sidebar-brand"><span className="monogram">SN</span><div><p className="eyebrow">PAINEL DA CHEFE</p><strong>Suzanny <em>Nail Designer</em></strong></div></div>
      <nav>{menu.map(item => { const Icon = item.icon; return <button key={item.id} className={tab === item.id ? "active" : ""} onClick={() => { setTab(item.id); setMobileNav(false); }}><Icon size={18} /> {item.label}<ChevronRight size={15} /></button>; })}</nav>
      <div className="sidebar-footer"><div className="staff-avatar">{(user.displayName || user.email || "S").slice(0, 1).toUpperCase()}</div><div className="staff-meta"><strong>{user.displayName || actor.name || "Equipe"}</strong><small>{isAdmin ? "Admin" : "Recepção"}</small></div><button onClick={() => void onLogout()} title="Sair"><LogOut size={16} /></button></div>
    </aside>
    <div className="admin-main">
      <header className="admin-topbar"><button className="mobile-menu" onClick={() => setMobileNav(!mobileNav)}><Menu size={20} /></button><div><p className="eyebrow gold">BOM TRABALHO, {(actor.name || user.displayName || "EQUIPE").split(" ")[0]?.toUpperCase()}</p><h1>{menu.find(item => item.id === tab)?.label}</h1></div><div className="topbar-date"><span>Hoje</span><strong>{new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "short" }).format(new Date())}</strong></div></header>
      <main className="admin-content">
        {dashboard.isError && <div className="notice error" role="alert">Não foi possível atualizar a agenda agora. Tente novamente em alguns instantes.</div>}
        {tab === "agenda" ? <Agenda date={date} setDate={setDate} dashboard={dashboard} occupied={occupied} statusMutation={statusMutation} /> : tab === "financas" ? <Finances appointments={allAppointments} last30={last30} crm={crm.data || []} /> : tab === "servicos" ? <Services currentServices={currentServices} form={serviceForm} setForm={setServiceForm} save={saveService} deactivate={deactivateService} /> : tab === "bloqueios" ? <Blocks blocks={blocksQuery.data || []} form={blockForm} setForm={setBlockForm} create={createBlock} remove={deleteBlock} /> : <Team team={teamQuery.data || []} form={teamForm} setForm={setTeamForm} save={saveTeam} remove={removeTeam} />}
      </main>
    </div>
  </div>;
}

function Agenda({ date, setDate, dashboard, occupied, statusMutation }: { date: string; setDate: (value: string) => void; dashboard: { data?: DashboardData }; occupied: Set<string>; statusMutation: ReturnType<typeof trpc.staff.updateStatus.useMutation> }) {
  const appointments = (dashboard.data?.appointments || []) as AppointmentRow[];
  const blocks = (dashboard.data?.blocks || []) as Array<Record<string, string | null>>;
  const slots = buildSlots("07:00", "21:00");
  return <><div className="metric-row"><div className="metric-card featured"><span>FATURAMENTO DO DIA</span><strong>{currency(dashboard.data?.revenue || 0)}</strong><small>Agendado + concluído</small></div><div className="metric-card"><span>ATENDIMENTOS</span><strong>{appointments.filter(item => item.status !== "Cancelado").length}</strong><small>Na data selecionada</small></div><div className="metric-card"><span>OCUPAÇÃO</span><strong>{Math.round((occupied.size / slots.length) * 100)}%</strong><small>Mapa térmico de hoje</small></div><label className="date-filter"><CalendarDays size={17} /><input type="date" value={date} onChange={event => setDate(event.target.value)} /></label></div><div className="panel-card"><div className="panel-card-head"><div><p className="eyebrow gold">MAPA TÉRMICO</p><h2>{dateLabel(date)}</h2></div><span className="live-pill"><i /> ao vivo</span></div><div className="heatmap">{slots.map(slot => { const item = appointments.find(candidate => candidate.status !== "Cancelado" && slot >= candidate.startTime && slot < candidate.endTime); const blocked = blocks.some(block => block.kind === "day" || (slot >= (block.startTime || "00:00") && slot <= (block.endTime || block.startTime || "00:00"))); return <div key={slot} className={`heat-cell ${blocked ? "blocked" : item ? "busy" : "free"}`} title={item ? `${item.customerName} · ${item.mainServiceName}` : blocked ? "Folga / bloqueio" : "Livre"}><small>{slot}</small>{item && <b>{item.customerName}</b>}</div>; })}</div><div className="legend"><span><i className="free" /> Livre</span><span><i className="busy" /> Ocupado</span><span><i className="blocked" /> Folga</span></div></div><div className="panel-card"><div className="panel-card-head"><div><p className="eyebrow gold">CLIENTES DO DIA</p><h2>Agenda de atendimento</h2></div><span className="count-badge">{appointments.length}</span></div>{appointments.length ? <div className="appointment-list">{appointments.map(item => <div className="appointment-row" key={item.id}><div className="appointment-time">{item.startTime}<small>{item.endTime}</small></div><div className="appointment-person"><strong>{item.customerName}</strong><span>{item.mainServiceName} · {currency(Number(item.price || 0))}</span></div>{Number(item.paidAmount || item.price) < Number(item.price || 0) && <span className="fraud-alert"><AlertTriangle size={14} /> valor abaixo da tabela</span>}<select value={item.status} disabled={statusMutation.isPending} onChange={event => statusMutation.mutate({ id: item.id, status: event.target.value as AppointmentRow["status"] })}><option>Agendado</option><option>Concluído</option><option>Cancelado</option><option>Faltou</option></select></div>)}</div> : <div className="empty-state">Ainda não há atendimentos nesta data.</div>}</div></>;
}

function Finances({ appointments, last30, crm }: { appointments: AppointmentRow[]; last30: AppointmentRow[]; crm: Array<{ name: string; phone: string; service: string; daysOverdue: number }> }) { const revenue = last30.reduce((sum, item) => sum + Number(item.paidAmount ?? item.price ?? 0), 0); return <><div className="metric-row"><div className="metric-card featured"><span>FATURAMENTO · 30 DIAS</span><strong>{currency(revenue)}</strong><small>Agendado + concluído</small></div><div className="metric-card"><span>ATENDIMENTOS</span><strong>{last30.length}</strong><small>Últimos 30 dias</small></div><div className="metric-card"><span>TICKET MÉDIO</span><strong>{currency(last30.length ? revenue / last30.length : 0)}</strong><small>Por atendimento</small></div></div><div className="panel-card"><div className="panel-card-head"><div><p className="eyebrow gold">VISÃO REAL</p><h2>Histórico financeiro</h2></div></div><div className="finance-table"><div className="table-head"><span>Cliente</span><span>Serviço</span><span>Data</span><span>Valor</span></div>{appointments.slice(0, 12).map(item => <div className="table-row" key={item.id}><strong>{item.customerName}</strong><span>{item.mainServiceName}</span><span>{item.date}</span><b>{currency(Number(item.paidAmount ?? item.price ?? 0))}</b></div>)}</div></div><div className="panel-card crm-card"><div><p className="eyebrow gold">INTELIGÊNCIA DE CRM</p><h2>Retornos para cobrar</h2><p>Clientes que já passaram da manutenção e ainda não têm um horário futuro.</p></div><div className="crm-empty">{crm.length ? <div className="crm-list">{crm.map(item => <div className="crm-row" key={item.phone}><div><strong>{item.name}</strong><span>{item.service} · {item.daysOverdue} dias vencidos</span></div><a href={safeWhatsApp(item.phone, `Oi ${item.name}, vi que passou ${item.daysOverdue} dias da sua ${item.service}. Vamos marcar?`)} target="_blank" rel="noreferrer">Cobrar ↗</a></div>)}</div> : <><ShieldCheck size={24} /> <span>O radar será preenchido quando existirem atendimentos com dias de manutenção.</span></>}</div></div></>; }

function Services({ currentServices, form, setForm, save, deactivate }: { currentServices: Service[]; form: { id: string; name: string; kind: "main" | "addon"; price: number; durationMinutes: number; maintenanceDays: number; description: string; active: boolean }; setForm: (value: typeof form) => void; save: ReturnType<typeof trpc.staff.saveService.useMutation>; deactivate: ReturnType<typeof trpc.staff.deactivateService.useMutation> }) { return <div className="admin-grid"><div className="panel-card"><div className="panel-card-head"><div><p className="eyebrow gold">CATÁLOGO</p><h2>Serviços ativos</h2></div></div><div className="service-admin-list">{currentServices.map(item => <div className="service-admin-row" key={item.id}><div><strong>{item.name}</strong><span>{item.kind === "main" ? `${item.durationMinutes} min · manutenção ${item.maintenanceDays} dias` : "Adicional · sem tempo extra"}</span></div><b>{currency(item.price)}</b>{item.active && <button disabled={deactivate.isPending} onClick={() => deactivate.mutate({ id: item.id })}><Trash2 size={15} /></button>}</div>)}</div></div><div className="panel-card form-card"><p className="eyebrow gold">NOVO OU EDITAR</p><h2>Atualizar serviço</h2><div className="form-grid"><label className="input-label">Nome<input value={form.name} onChange={event => setForm({ ...form, name: event.target.value })} /></label><label className="input-label">Tipo<select value={form.kind} onChange={event => setForm({ ...form, kind: event.target.value as "main" | "addon" })}><option value="main">Principal</option><option value="addon">Adicional</option></select></label><label className="input-label">Preço<input type="number" min="0" value={form.price} onChange={event => setForm({ ...form, price: Number(event.target.value) })} /></label><label className="input-label">Duração<input type="number" min="0" disabled={form.kind === "addon"} value={form.durationMinutes} onChange={event => setForm({ ...form, durationMinutes: Number(event.target.value) })} /></label><label className="input-label">Manutenção<input type="number" min="0" value={form.maintenanceDays} onChange={event => setForm({ ...form, maintenanceDays: Number(event.target.value) })} /></label></div><button className="gold-button full" disabled={save.isPending || form.name.trim().length < 2} onClick={() => save.mutate(form)}><Check size={17} /> Salvar serviço</button></div></div>; }

function Blocks({ blocks, form, setForm, create, remove }: { blocks: Array<Record<string, string | null>>; form: { date: string; kind: "slot" | "period" | "day"; startTime: string; endTime: string; reason: string }; setForm: (value: typeof form) => void; create: ReturnType<typeof trpc.staff.createBlock.useMutation>; remove: ReturnType<typeof trpc.staff.deleteBlock.useMutation> }) { return <div className="admin-grid"><div className="panel-card"><p className="eyebrow gold">DISPONIBILIDADE</p><h2>Novo bloqueio</h2><div className="form-grid"><label className="input-label">Data<input type="date" value={form.date} onChange={event => setForm({ ...form, date: event.target.value })} /></label><label className="input-label">Tipo<select value={form.kind} onChange={event => setForm({ ...form, kind: event.target.value as typeof form.kind })}><option value="slot">15 minutos</option><option value="period">Período</option><option value="day">Dia inteiro</option></select></label>{form.kind !== "day" && <><label className="input-label">De<input type="time" step="900" value={form.startTime} onChange={event => setForm({ ...form, startTime: event.target.value })} /></label><label className="input-label">Até<input type="time" step="900" value={form.endTime} onChange={event => setForm({ ...form, endTime: event.target.value })} /></label></>}<label className="input-label">Nota privada<input value={form.reason} onChange={event => setForm({ ...form, reason: event.target.value })} placeholder="Almoço, compromisso…" /></label></div><button className="gold-button full" disabled={create.isPending} onClick={() => create.mutate(form)}><Plus size={17} /> Criar bloqueio</button></div><div className="panel-card"><p className="eyebrow gold">BLOQUEIOS ATIVOS</p><h2>Agenda pessoal</h2><div className="block-list">{blocks.map(block => <div className="block-row" key={String(block.id)}><div><strong>{String(block.date)}</strong><span>{block.kind === "day" ? "Dia inteiro" : `${block.startTime} – ${block.endTime}`}</span></div><button disabled={remove.isPending} onClick={() => remove.mutate({ id: String(block.id) })}><X size={16} /></button></div>)}</div></div></div>; }

function Team({ team, form, setForm, save, remove }: { team: Array<Record<string, string | boolean | null>>; form: { email: string; name: string; role: "admin" | "reception" }; setForm: (value: typeof form) => void; save: ReturnType<typeof trpc.staff.saveTeamMember.useMutation>; remove: ReturnType<typeof trpc.staff.removeTeamMember.useMutation> }) { return <div className="admin-grid"><div className="panel-card"><p className="eyebrow gold">ACESSOS</p><h2>Convidar para a equipe</h2><p className="panel-description">Cadastre o e-mail. A funcionária cria a própria senha pelo primeiro acesso.</p><label className="input-label">E-mail<input type="email" value={form.email} onChange={event => setForm({ ...form, email: event.target.value })} placeholder="equipe@exemplo.com" /></label><label className="input-label">Nome<input value={form.name} onChange={event => setForm({ ...form, name: event.target.value })} /></label><label className="input-label">Papel<select value={form.role} onChange={event => setForm({ ...form, role: event.target.value as typeof form.role })}><option value="reception">Recepção</option><option value="admin">Admin</option></select></label><button className="gold-button full" disabled={save.isPending || !form.email.includes("@")} onClick={() => save.mutate(form)}><Plus size={17} /> Salvar convite</button></div><div className="panel-card"><p className="eyebrow gold">EQUIPE AUTORIZADA</p><h2>Quem cuida do ateliê</h2><div className="team-list">{team.map(member => <div className="team-row" key={String(member.id)}><div className="staff-avatar">{String(member.name || member.email).slice(0, 1).toUpperCase()}</div><div><strong>{String(member.name || member.email)}</strong><span>{String(member.email)} · {member.role === "admin" ? "Admin" : "Recepção"}</span></div><button disabled={remove.isPending} onClick={() => remove.mutate({ email: String(member.email) })}><Trash2 size={15} /></button></div>)}</div></div></div>; }

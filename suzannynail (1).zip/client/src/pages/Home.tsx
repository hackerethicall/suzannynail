import { useEffect, useMemo, useState } from "react";
import { CalendarDays, Check, ChevronRight, Clock3, ExternalLink, Instagram, Loader2, MapPin, MessageCircle, ShieldCheck, Sparkles, WandSparkles } from "lucide-react";
import { Link } from "wouter";
import { defaultServices, buildSlots, businessDateIso, currency, dateLabel, endTimeFor, fromMinutes, toMinutes, type AvailabilityBlock, type PublicSlot } from "@shared/domain";
import { trpc } from "@/lib/trpc";
import { firebaseConfigured, listenToDayAvailability } from "@/lib/firebase";

const BUSINESS_WHATSAPP = import.meta.env.VITE_BUSINESS_WHATSAPP || "https://wa.me/?text=Olá!%20Preciso%20falar%20sobre%20um%20agendamento.";
const INSTAGRAM_URL = import.meta.env.VITE_INSTAGRAM_URL || "#portfolio";
const MAPS_URL = import.meta.env.VITE_MAPS_URL || "#localizacao";

function isoToday() { return businessDateIso(); }
function isoPlus(days: number) { return businessDateIso(days); }

function isSlotBlocked(time: string, slots: PublicSlot[], blocks: AvailabilityBlock[]) {
  const taken = slots.some(slot => slot.time === time);
  return taken || blocks.some(block => {
    if (block.kind === "day") return true;
    const from = block.startTime || "00:00";
    const to = block.endTime || from;
    return time >= from && time <= to;
  });
}

export default function Home() {
  const catalogQuery = trpc.catalog.services.useQuery(undefined, { staleTime: 60_000 });
  const firebaseStatus = trpc.firebase.status.useQuery(undefined, { retry: false, staleTime: 60_000 });
  const booking = trpc.booking.create.useMutation();
  const [date, setDate] = useState(isoPlus(1));
  const [mainId, setMainId] = useState("main-fibra");
  const [addonIds, setAddonIds] = useState<string[]>([]);
  const [time, setTime] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [consent, setConsent] = useState(false);
  const [live, setLive] = useState<{ slots: PublicSlot[]; blocks: AvailabilityBlock[] }>({ slots: [], blocks: [] });
  const [liveError, setLiveError] = useState("");
  const [notice, setNotice] = useState<{ type: "success" | "error"; message: string } | null>(null);
  const [showException, setShowException] = useState(false);

  const services = catalogQuery.data?.length ? catalogQuery.data : defaultServices;
  const mainServices = services.filter(item => item.kind === "main" && item.active);
  const addons = services.filter(item => item.kind === "addon" && item.active);
  const main = mainServices.find(item => item.id === mainId) || mainServices[0] || defaultServices[0];
  const selectedAddons = addons.filter(item => addonIds.includes(item.id));
  const total = main.price + selectedAddons.reduce((sum, item) => sum + item.price, 0);
  const bookingUnavailable = !firebaseConfigured || (firebaseStatus.isSuccess && !firebaseStatus.data.ready);
  const maxDate = isoPlus(60);
  const today = isoToday();
  const slots = useMemo(() => buildSlots("07:00", "21:00").filter(candidate => {
    if (toMinutes(candidate) > 1080) return false;
    const now = new Date();
    if (date === today && toMinutes(candidate) <= now.getHours() * 60 + now.getMinutes()) return false;
    const serviceSlots = Math.ceil(main.durationMinutes / 15);
    const start = toMinutes(candidate);
    const corridor = Array.from({ length: serviceSlots }, (_, index) => fromMinutes(start + index * 15));
    return corridor.every(item => toMinutes(item) < 1260 && !isSlotBlocked(item, live.slots, live.blocks));
  }), [date, live.blocks, live.slots, main.durationMinutes, today]);
  const dayClosed = live.blocks.some(item => item.kind === "day");
  const chosenTimeIsLate = Boolean(time && toMinutes(time) + main.durationMinutes > 1140);

  useEffect(() => {
    setTime("");
    setLiveError("");
    if (!firebaseConfigured) {
      setLiveError("A agenda está em configuração e ainda não recebe reservas online.");
      return;
    }
    return listenToDayAvailability(date, setLive, error => setLiveError("A disponibilidade está sendo atualizada. Tente novamente em instantes."));
  }, [date]);

  useEffect(() => {
    if (mainServices[0] && !mainServices.some(item => item.id === mainId)) setMainId(mainServices[0].id);
  }, [mainId, mainServices]);

  function toggleAddon(id: string) { setAddonIds(current => current.includes(id) ? current.filter(item => item !== id) : [...current, id]); }
  function submit(event: React.FormEvent) {
    event.preventDefault();
    if (bookingUnavailable) return setNotice({ type: "error", message: "A agenda online ainda está em configuração. Fale conosco pelo WhatsApp para combinar seu horário." });
    if (!time) return setNotice({ type: "error", message: "Escolha um horário para continuar." });
    if (!consent) return setNotice({ type: "error", message: "Confirme o uso dos seus dados para o atendimento." });
    if (chosenTimeIsLate) return setShowException(true);
    const key = `suzanny-bookings-${date}`;
    const count = Number(localStorage.getItem(key) || "0");
    if (count >= 2) return setNotice({ type: "error", message: "Para garantir uma agenda justa, este aparelho já atingiu o limite de 2 agendamentos no dia. Fale conosco pelo WhatsApp." });
    booking.mutate({ date, startTime: time, mainServiceId: main.id, addonIds, customerName: name, customerPhone: phone, consent: true }, { onSuccess: result => { localStorage.setItem(key, String(count + 1)); setNotice({ type: "success", message: `Horário reservado. Seu atendimento de ${dateLabel(date)} às ${time} foi registrado.` }); setTime(""); setName(""); setPhone(""); setAddonIds([]); setConsent(false); console.info("appointment", result.id); }, onError: error => setNotice({ type: "error", message: error.message || "Não foi possível reservar este horário." }) });
  }
  const exceptionText = `Olá, Suzanny! Gostaria de solicitar uma exceção para ${dateLabel(date)} às ${time}, para ${main.name}.`;

  return <div className="min-h-screen bg-[#f8f6f1] text-[#26313c]">
    <header className="hero-shell">
      <nav className="page-width flex items-center justify-between py-5">
        <div className="brand-lockup"><span className="monogram">SN</span><div><p className="eyebrow">ATELIÊ DE CUIDADO</p><p className="brand-name">Suzanny <em>Nail Designer</em></p></div></div>
        <div className="flex items-center gap-3"><Link href="/admin" className="quiet-link">Acesso da equipe</Link><a href={BUSINESS_WHATSAPP} target="_blank" rel="noreferrer" className="top-action"><MessageCircle size={15} /> WhatsApp</a></div>
      </nav>
      <div className="page-width hero-grid">
        <div className="hero-copy"><p className="eyebrow gold">BELEZA COM HORA MARCADA</p><h1>Seu próximo momento de cuidado.</h1><p className="hero-subtitle">Uma agenda feita para você escolher com calma, receber com precisão e sair se sentindo ainda mais você.</p><a href="#agenda" className="gold-button">Escolher meu horário <ChevronRight size={18} /></a><div className="trust-line"><ShieldCheck size={17} /> Agenda organizada, dados protegidos.</div></div>
        <div className="hero-card"><div className="card-ornament"><Sparkles size={18} /><span>ATENDIMENTO PERSONALIZADO</span></div><div className="hero-card-line" /><p>Unhas bem cuidadas não são detalhe. São a assinatura do seu tempo.</p><div className="hero-card-foot"><span>SN</span><span>desde 2024</span></div></div>
      </div>
    </header>

    <main id="agenda" className="page-width booking-layout">
      <section className="booking-intro"><div><p className="eyebrow gold">RESERVE SEU HORÁRIO</p><h2>Escolha o que combina com você.</h2></div><p className="section-note">{bookingUnavailable ? "A agenda online está sendo configurada. Para reservar, fale diretamente pelo WhatsApp." : "A disponibilidade é atualizada ao vivo. Os adicionais somam ao valor, sem tomar mais tempo da sua sessão."}</p></section>
      <form onSubmit={submit} className="booking-card">
        <div className="step-column"><div className="step-heading"><span>01</span><div><p className="eyebrow">SEU SERVIÇO</p><h3>Comece pelo essencial</h3></div></div><div className="service-list">{mainServices.map(service => <button type="button" key={service.id} className={`service-option ${main.id === service.id ? "selected" : ""}`} onClick={() => setMainId(service.id)}><div><strong>{service.name}</strong><small>{service.description || `${service.durationMinutes} min de cuidado`}</small></div><span>{currency(service.price)}</span></button>)}</div><div className="addon-box"><div className="addon-title"><WandSparkles size={17} /><span>Detalhes que fazem diferença</span></div>{addons.map(addon => <label className="check-row" key={addon.id}><input type="checkbox" checked={addonIds.includes(addon.id)} onChange={() => toggleAddon(addon.id)} /><span className="custom-check">{addonIds.includes(addon.id) && <Check size={13} />}</span><span>{addon.name}</span><b>+ {currency(addon.price)}</b></label>)}</div></div>
        <div className="step-column"><div className="step-heading"><span>02</span><div><p className="eyebrow">DIA E HORA</p><h3>Seu tempo, do seu jeito</h3></div></div><div className="date-field"><CalendarDays size={18} /><div><label htmlFor="date">Escolha uma data</label><input id="date" type="date" min={today} max={maxDate} value={date} onChange={event => setDate(event.target.value)} /></div></div>{dayClosed ? <div className="closed-banner">Neste dia estaremos fechados por motivos pessoais. Por favor, escolha outra data.</div> : <><div className="time-grid">{slots.map(item => <button type="button" key={item} className={`time-button ${time === item ? "selected" : ""} ${toMinutes(item) + main.durationMinutes > 1140 ? "late" : ""}`} onClick={() => { setTime(item); if (toMinutes(item) + main.durationMinutes > 1140) setShowException(true); }}>{item}</button>)}</div>{liveError && <p className="field-hint">{liveError}</p>}{!slots.length && <p className="empty-state">Não encontramos um corredor livre nesta data. Tente outro dia.</p>}</>}</div>
        <div className="step-column client-column"><div className="step-heading"><span>03</span><div><p className="eyebrow">SEUS DADOS</p><h3>Para confirmar sua reserva</h3></div></div><label className="input-label">Seu nome<input value={name} onChange={event => setName(event.target.value)} maxLength={100} required placeholder="Como podemos te chamar?" /></label><label className="input-label">WhatsApp<input value={phone} onChange={event => setPhone(event.target.value)} maxLength={100} required placeholder="(00) 00000-0000" /></label><div className="summary-box"><div><span>{main.name}</span><strong>{currency(total)}</strong></div><small>{time ? `${dateLabel(date)} · ${time}–${endTimeFor(time, main.durationMinutes)}` : "Escolha seu horário para ver o resumo"}</small></div><label className="consent-row"><input type="checkbox" checked={consent} onChange={event => setConsent(event.target.checked)} /><span className="custom-check">{consent && <Check size={13} />}</span><span>Autorizo o uso do meu nome e WhatsApp para confirmar e realizar este atendimento.</span></label><button type="submit" className="gold-button full" disabled={booking.isPending || !time || dayClosed || bookingUnavailable}>{booking.isPending ? <Loader2 className="spin" size={18} /> : <CalendarDays size={18} />} {bookingUnavailable ? "Agenda em configuração" : booking.isPending ? "Confirmando…" : "Confirmar agendamento"}</button><p className="privacy-note"><ShieldCheck size={14} /> Seus dados ficam protegidos e são usados apenas para o atendimento.</p>{notice && <div className={`notice ${notice.type}`}>{notice.message}{notice.type === "error" && <a href={BUSINESS_WHATSAPP} target="_blank" rel="noreferrer"> Falar no WhatsApp</a>}</div>}</div>
      </form>
    </main>

    <section className="signature-strip"><div className="page-width signature-grid"><div><p className="eyebrow gold">RITUAL DE CUIDADO</p><h2>Pequenos detalhes.<br /><em>Grande presença.</em></h2></div><div className="signature-copy"><p>Do primeiro toque ao último brilho, cada atendimento é pensado para respeitar seu tempo e celebrar seu estilo.</p><div className="signature-links"><a href={MAPS_URL}><MapPin size={16} /> Como chegar <ExternalLink size={12} /></a><a href={INSTAGRAM_URL}><Instagram size={16} /> Portfólio <ExternalLink size={12} /></a></div></div></div></section>
    <footer className="footer"><div className="page-width flex flex-wrap items-center justify-between gap-4"><div className="brand-lockup"><span className="monogram small">SN</span><p className="brand-name">Suzanny <em>Nail Designer</em></p></div><p>© 2026 · feito para o seu tempo</p><a href={BUSINESS_WHATSAPP} target="_blank" rel="noreferrer">Avisar imprevisto no WhatsApp ↗</a></div></footer>

    {showException && <div className="modal-backdrop" role="presentation" onMouseDown={() => setShowException(false)}><div className="modal-card" onMouseDown={event => event.stopPropagation()}><div className="modal-icon"><Clock3 size={21} /></div><p className="eyebrow gold">AUTORIZAÇÃO ESPECIAL</p><h3>Esse horário termina depois das 19h.</h3><p>Para preservar seu atendimento com calma, a Suzanny precisa aprovar essa exceção para <strong>{dateLabel(date)} às {time}</strong>.</p><a className="gold-button full" href={`${BUSINESS_WHATSAPP}&text=${encodeURIComponent(exceptionText)}`} target="_blank" rel="noreferrer"><MessageCircle size={18} /> Pedir aprovação pelo WhatsApp</a><button className="modal-close" type="button" onClick={() => setShowException(false)}>Voltar e escolher outro horário</button></div></div>}
  </div>;
}

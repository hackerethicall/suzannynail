import { getApp, getApps, initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { collection, getFirestore, onSnapshot, orderBy, query, where, type Unsubscribe } from "firebase/firestore";
import type { Service, AvailabilityBlock, PublicSlot } from "@shared/domain";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

export const firebaseConfigured = Boolean(firebaseConfig.apiKey && firebaseConfig.authDomain && firebaseConfig.projectId && firebaseConfig.appId);
export const firebaseApp = firebaseConfigured ? (getApps().length ? getApp() : initializeApp(firebaseConfig)) : null;
export const firebaseAuth = firebaseApp ? getAuth(firebaseApp) : null;
export const firestore = firebaseApp ? getFirestore(firebaseApp) : null;

export function listenToDayAvailability(date: string, onChange: (data: { slots: PublicSlot[]; blocks: AvailabilityBlock[] }) => void, onError?: (error: Error) => void): Unsubscribe {
  if (!firestore) {
    onChange({ slots: [], blocks: [] });
    return () => undefined;
  }
  let slots: PublicSlot[] = [];
  let blocks: AvailabilityBlock[] = [];
  const publish = () => onChange({ slots, blocks });
  const stopSlots = onSnapshot(query(collection(firestore, "public_slots"), where("date", "==", date), orderBy("time")), snap => {
    slots = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as PublicSlot));
    publish();
  }, error => onError?.(error));
  const stopBlocks = onSnapshot(query(collection(firestore, "public_blocks"), where("date", "==", date)), snap => {
    blocks = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as AvailabilityBlock));
    publish();
  }, error => onError?.(error));
  return () => { stopSlots(); stopBlocks(); };
}

export function listenToServices(onChange: (services: Service[]) => void, onError?: (error: Error) => void): Unsubscribe {
  if (!firestore) { onChange([]); return () => undefined; }
  return onSnapshot(query(collection(firestore, "services"), where("active", "==", true)), snap => {
    onChange(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Service)));
  }, error => onError?.(error));
}

export type ServiceKind = "main" | "addon";
export type AppointmentStatus = "Agendado" | "Concluído" | "Cancelado" | "Faltou";
export type BlockKind = "slot" | "period" | "day";
export type StaffRole = "admin" | "reception";

export type Service = {
  id: string;
  name: string;
  kind: ServiceKind;
  price: number;
  durationMinutes: number;
  maintenanceDays: number;
  active: boolean;
  description?: string;
};

export type Appointment = {
  id: string;
  date: string;
  startTime: string;
  endTime: string;
  mainServiceId: string;
  mainServiceName: string;
  addonIds: string[];
  addonNames: string[];
  customerName: string;
  customerPhone: string;
  price: number;
  paidAmount?: number;
  status: AppointmentStatus;
  createdAt?: string;
};

export type PublicSlot = {
  id: string;
  date: string;
  time: string;
};

export type AvailabilityBlock = {
  id: string;
  date: string;
  kind: BlockKind;
  startTime?: string;
  endTime?: string;
  reason?: string;
};

export type TeamMember = {
  id: string;
  email: string;
  name?: string;
  role: StaffRole;
  active: boolean;
};

export const defaultServices: Service[] = [
  { id: "main-fibra", name: "Alongamento em fibra", kind: "main", price: 160, durationMinutes: 120, maintenanceDays: 20, active: true, description: "Estrutura resistente com acabamento impecável." },
  { id: "main-gel", name: "Banho de gel", kind: "main", price: 120, durationMinutes: 90, maintenanceDays: 18, active: true, description: "Brilho intenso e proteção para suas unhas naturais." },
  { id: "main-manicure", name: "Manicure premium", kind: "main", price: 65, durationMinutes: 60, maintenanceDays: 14, active: true, description: "Cuidado completo, cuticulagem e esmaltação." },
  { id: "addon-french", name: "Francesinha delicada", kind: "addon", price: 15, durationMinutes: 0, maintenanceDays: 0, active: true },
  { id: "addon-decoration", name: "Decoração especial", kind: "addon", price: 25, durationMinutes: 0, maintenanceDays: 0, active: true },
  { id: "addon-cuticle", name: "Cutilagem express", kind: "addon", price: 20, durationMinutes: 0, maintenanceDays: 0, active: true },
];

export function toMinutes(time: string): number {
  const [hours, minutes] = time.split(":").map(Number);
  return hours * 60 + minutes;
}

export function fromMinutes(total: number): string {
  const hours = Math.floor(total / 60).toString().padStart(2, "0");
  const minutes = (total % 60).toString().padStart(2, "0");
  return `${hours}:${minutes}`;
}

export function buildSlots(start: string, end: string): string[] {
  const slots: string[] = [];
  for (let minute = toMinutes(start); minute < toMinutes(end); minute += 15) slots.push(fromMinutes(minute));
  return slots;
}

export function endTimeFor(start: string, durationMinutes: number): string {
  return fromMinutes(toMinutes(start) + durationMinutes);
}

export function currency(value: number): string {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(value);
}

export function safeWhatsApp(phone: string, text: string): string {
  const digits = phone.replace(/\\D/g, "");
  return `https://wa.me/${digits}?text=${encodeURIComponent(text)}`;
}

export function dateLabel(date: string): string {
  return new Intl.DateTimeFormat("pt-BR", { weekday: "long", day: "2-digit", month: "long" }).format(new Date(`${date}T12:00:00`));
}

export const BUSINESS_TIME_ZONE = "America/Sao_Paulo";

export function businessDateIso(offsetDays = 0): string {
  const base = new Date();
  const current = new Intl.DateTimeFormat("en-CA", { timeZone: BUSINESS_TIME_ZONE, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(base);
  const year = Number(current.find(part => part.type === "year")?.value);
  const month = Number(current.find(part => part.type === "month")?.value);
  const day = Number(current.find(part => part.type === "day")?.value);
  const result = new Date(Date.UTC(year, month - 1, day + offsetDays));
  return result.toISOString().slice(0, 10);
}

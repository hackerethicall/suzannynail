import { z } from "zod";
import { Timestamp } from "firebase-admin/firestore";
import { businessDateIso, defaultServices, type Service } from "@shared/domain";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { firebaseAdminProcedure, firebaseStaffProcedure, publicProcedure, router } from "./_core/trpc";
import { adminDb, firebaseAdminStatus, firebaseServiceStatus } from "./firebaseAdmin";

const serviceInput = z.object({
  id: z.string().min(1).max(80), name: z.string().trim().min(2).max(100), kind: z.enum(["main", "addon"]), price: z.number().min(0).max(10000), durationMinutes: z.number().int().min(0).max(480), maintenanceDays: z.number().int().min(0).max(180), description: z.string().trim().max(240).optional(), active: z.boolean().default(true),
}).strict();
const bookingInput = z.object({
  date: z.string().regex(/^20\\d{2}-\\d{2}-\\d{2}$/), startTime: z.string().regex(/^([01]\\d|2[0-3]):[0-5]\\d$/), mainServiceId: z.string().min(1), addonIds: z.array(z.string()).max(8), customerName: z.string().trim().min(2).max(100), customerPhone: z.string().trim().min(8).max(100), consent: z.literal(true),
}).strict();

function ensureDateWindow(date: string, allowPast = false) {
  const parsed = new Date(`${date}T12:00:00Z`);
  if (Number.isNaN(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== date || Number(date.slice(0, 4)) < 2026) throw new Error("Escolha uma data válida.");
  const today = businessDateIso();
  const max = businessDateIso(60);
  if (!allowPast && (date < today || date > max)) throw new Error("Escolha uma data entre hoje e 60 dias à frente.");
}
function slotsFor(date: string, startTime: string, durationMinutes: number) {
  const [hour, minute] = startTime.split(":").map(Number);
  const start = hour * 60 + minute;
  return Array.from({ length: Math.ceil(durationMinutes / 15) }, (_, index) => `${date}_${String(Math.floor((start + index * 15) / 60)).padStart(2, "0")}:${String((start + index * 15) % 60).padStart(2, "0")}`);
}
function money(value: number) { return Math.round(value * 100) / 100; }
function toMinutes(time: string) { const [hour, minute] = time.split(":").map(Number); return hour * 60 + minute; }
function blockSlotIds(date: string, kind: "slot" | "period" | "day", startTime?: string, endTime?: string) {
  if (kind === "day") return slotsFor(date, "07:00", 14 * 60);
  if (!startTime || !/^([01]\\d|2[0-3]):[0-5]\\d$/.test(startTime)) throw new Error("Informe um horário inicial válido.");
  const end = endTime || startTime;
  const duration = kind === "slot" ? 15 : toMinutes(end) - toMinutes(startTime) + 15;
  if (duration <= 0 || toMinutes(startTime) % 15 !== 0 || toMinutes(end) % 15 !== 0) throw new Error("O bloqueio deve usar intervalos de 15 minutos.");
  return slotsFor(date, startTime, duration);
}

async function readActiveServices(): Promise<Service[]> {
  if (!firebaseAdminStatus().ready) return defaultServices;
  try {
    const snapshot = await adminDb().collection("services").where("active", "==", true).get();
    if (!snapshot.empty) return snapshot.docs.map(item => ({ id: item.id, ...item.data() } as Service));
  } catch (error) { console.warn("[Firestore] services unavailable", error instanceof Error ? error.message : "unknown"); }
  return defaultServices;
}

export const appRouter = router({
  system: systemRouter,
  firebase: router({
    status: publicProcedure.query(() => firebaseServiceStatus()),
  }),
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => { const cookieOptions = getSessionCookieOptions(ctx.req); ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 }); return { success: true } as const; }),
  }),
  catalog: router({
    services: publicProcedure.query(() => readActiveServices()),
  }),
  invite: router({
    check: publicProcedure.input(z.object({ email: z.string().email().max(320) }).strict()).query(async ({ input }) => {
      if (!firebaseAdminStatus().ready) return { allowed: false };
      try {
        const member = await adminDb().collection("team").doc(input.email.toLowerCase()).get();
        return { allowed: member.exists && member.data()?.active !== false };
      } catch {
        return { allowed: false };
      }
    }),
  }),
  booking: router({
    create: publicProcedure.input(bookingInput).mutation(async ({ input }) => {
      ensureDateWindow(input.date);
      const db = adminDb();
      const services = await readActiveServices();
      const main = services.find(service => service.id === input.mainServiceId && service.kind === "main" && service.active);
      const addons = services.filter(service => input.addonIds.includes(service.id) && service.kind === "addon" && service.active);
      if (!main) throw new Error("Escolha um serviço principal válido.");
      if (main.durationMinutes <= 0 || main.durationMinutes % 15 !== 0) throw new Error("Este serviço ainda não tem uma duração válida configurada.");
      const total = money(main.price + addons.reduce((sum, service) => sum + service.price, 0));
      const slotIds = slotsFor(input.date, input.startTime, main.durationMinutes);
      const startMinutes = Number(input.startTime.slice(0, 2)) * 60 + Number(input.startTime.slice(3));
      if (startMinutes < 420 || startMinutes >= 1080 || startMinutes % 15 !== 0) throw new Error("Horário indisponível para reserva online.");
      const endMinutes = startMinutes + main.durationMinutes;
      if (endMinutes > 1260) throw new Error("Este horário precisa de autorização especial pelo WhatsApp.");
      const appointmentRef = db.collection("appointments").doc();
      await db.runTransaction(async transaction => {
        const slotRefs = slotIds.map(id => db.collection("public_slots").doc(id));
        const existingSlots = await Promise.all(slotRefs.map(ref => transaction.get(ref)));
        if (existingSlots.some(snapshot => snapshot.exists)) throw new Error("Este horário acabou de ser reservado. Escolha outro.");
        const blockSnapshot = await transaction.get(db.collection("blocks").where("date", "==", input.date));
        const blocked = blockSnapshot.docs.some(block => {
          const data = block.data();
          if (data.kind === "day") return true;
          const from = data.startTime ?? data.time;
          const to = data.endTime ?? data.time;
          return slotIds.some(id => { const time = id.split("_")[1]; return time >= from && time <= to; });
        });
        if (blocked) throw new Error("Há um bloqueio neste horário. Escolha outro.");
        transaction.set(appointmentRef, { ...input, endTime: `${String(Math.floor(endMinutes / 60)).padStart(2, "0")}:${String(endMinutes % 60).padStart(2, "0")}`, mainServiceName: main.name, maintenanceDays: main.maintenanceDays, addonNames: addons.map(item => item.name), addonIds: addons.map(item => item.id), price: total, status: "Agendado", createdAt: Timestamp.now() });
        slotRefs.forEach((ref, index) => transaction.set(ref, { date: input.date, time: slotIds[index].split("_")[1] }));
      });
      return { id: appointmentRef.id, price: total };
    }),
  }),
  staff: router({
    me: firebaseStaffProcedure.query(({ ctx }) => ctx.firebaseActor),
    appointments: firebaseAdminProcedure.input(z.object({ date: z.string().optional() }).strict().optional()).query(async ({ input }) => {
      const snapshot = input?.date ? await adminDb().collection("appointments").where("date", "==", input.date).get() : await adminDb().collection("appointments").get();
      return snapshot.docs.map(item => ({ id: item.id, ...item.data() }));
    }),
    dashboard: firebaseStaffProcedure.input(z.object({ date: z.string() })).query(async ({ input }) => {
      ensureDateWindow(input.date, true);
      const [appointmentsSnapshot, blocksSnapshot] = await Promise.all([adminDb().collection("appointments").where("date", "==", input.date).get(), adminDb().collection("blocks").where("date", "==", input.date).get()]);
      const appointments = appointmentsSnapshot.docs.map(item => ({ id: item.id, ...item.data() })) as Array<Record<string, any> & { id: string }>;
      const revenue = appointments.filter(item => item.status === "Agendado" || item.status === "Concluído").reduce((sum, item) => sum + Number(item.paidAmount ?? item.price ?? 0), 0);
      return { appointments, blocks: blocksSnapshot.docs.map(item => ({ id: item.id, ...item.data() })), revenue };
    }),
    crm: firebaseAdminProcedure.query(async () => {
      const snapshot = await adminDb().collection("appointments").get();
      const all = snapshot.docs.map(item => ({ id: item.id, ...item.data() })) as Array<Record<string, any> & { id: string }>;
      const today = new Date(`${businessDateIso()}T12:00:00Z`).getTime();
      const candidates = all.filter(item => item.status === "Concluído" && Number(item.maintenanceDays || 0) > 0).map(item => {
        const due = new Date(`${item.date}T12:00:00Z`); due.setUTCDate(due.getUTCDate() + Number(item.maintenanceDays));
        return { ...item, dueAt: due.getTime(), daysOverdue: Math.max(0, Math.floor((today - due.getTime()) / 86400000)) };
      }) as unknown as Array<Record<string, any> & { customerPhone: string; customerName: string; mainServiceName: string; dueAt: number; daysOverdue: number }>;
      const overdue = candidates.filter(item => item.dueAt < today && !all.some(future => future.customerPhone === item.customerPhone && future.status !== "Cancelado" && new Date(`${future.date}T12:00:00Z`).getTime() >= today));
      const unique = new Map<string, (typeof overdue)[number]>(); overdue.sort((a, b) => b.dueAt - a.dueAt).forEach(item => { if (!unique.has(item.customerPhone)) unique.set(item.customerPhone, item); });
      return [...unique.values()].map(item => ({ name: item.customerName, phone: item.customerPhone, service: item.mainServiceName, daysOverdue: item.daysOverdue }));
    }),
    updateStatus: firebaseStaffProcedure.input(z.object({ id: z.string(), status: z.enum(["Agendado", "Concluído", "Cancelado", "Faltou"]) }).strict()).mutation(async ({ input }) => {
      const db = adminDb(); const appointmentRef = db.collection("appointments").doc(input.id);
      await db.runTransaction(async transaction => {
        const appointment = await transaction.get(appointmentRef);
        if (!appointment.exists) throw new Error("Agendamento não encontrado.");
        const data = appointment.data() as { date: string; startTime: string; endTime: string };
        const slotRefs = slotsFor(data.date, data.startTime, toMinutes(data.endTime) - toMinutes(data.startTime)).map(slotId => db.collection("public_slots").doc(slotId));
        const slotSnapshots = await Promise.all(slotRefs.map(ref => transaction.get(ref)));
        transaction.update(appointmentRef, { status: input.status, updatedAt: Timestamp.now() });
        if (input.status === "Cancelado") slotSnapshots.forEach((slot, index) => { if (slot.exists) transaction.delete(slotRefs[index]); });
      });
      return { success: true };
    }),
    services: firebaseAdminProcedure.query(() => readActiveServices()),
    saveService: firebaseAdminProcedure.input(serviceInput).mutation(async ({ input }) => { const { id, ...data } = input; await adminDb().collection("services").doc(id).set({ ...data, durationMinutes: input.kind === "addon" ? 0 : input.durationMinutes, updatedAt: Timestamp.now() }, { merge: true }); return { success: true }; }),
    deactivateService: firebaseAdminProcedure.input(z.object({ id: z.string() }).strict()).mutation(async ({ input }) => { await adminDb().collection("services").doc(input.id).set({ active: false, updatedAt: Timestamp.now() }, { merge: true }); return { success: true }; }),
    blocks: firebaseAdminProcedure.input(z.object({ date: z.string().optional() }).strict().optional()).query(async ({ input }) => { const snapshot = input?.date ? await adminDb().collection("blocks").where("date", "==", input.date).get() : await adminDb().collection("blocks").get(); return snapshot.docs.map(item => ({ id: item.id, ...item.data() })); }),
    createBlock: firebaseAdminProcedure.input(z.object({ date: z.string(), kind: z.enum(["slot", "period", "day"]), startTime: z.string().optional(), endTime: z.string().optional(), reason: z.string().trim().max(120).optional() }).strict()).mutation(async ({ input }) => { ensureDateWindow(input.date, true); const db = adminDb(); const slotIds = blockSlotIds(input.date, input.kind, input.startTime, input.endTime); const privateRef = db.collection("blocks").doc(); const publicRef = db.collection("public_blocks").doc(privateRef.id); await db.runTransaction(async transaction => { const slotRefs = slotIds.map(id => db.collection("public_slots").doc(id)); const existing = await Promise.all(slotRefs.map(ref => transaction.get(ref))); if (existing.some(snapshot => snapshot.exists)) throw new Error("Não é possível bloquear um horário que já está ocupado."); transaction.set(privateRef, { ...input, createdAt: Timestamp.now() }); transaction.set(publicRef, { date: input.date, kind: input.kind, startTime: input.startTime || null, endTime: input.endTime || input.startTime || null }); }); return { success: true }; }),
    deleteBlock: firebaseAdminProcedure.input(z.object({ id: z.string() }).strict()).mutation(async ({ input }) => { const db = adminDb(); const batch = db.batch(); batch.delete(db.collection("blocks").doc(input.id)); batch.delete(db.collection("public_blocks").doc(input.id)); await batch.commit(); return { success: true }; }),
    team: firebaseAdminProcedure.query(async () => { const snapshot = await adminDb().collection("team").get(); return snapshot.docs.map(item => ({ id: item.id, ...item.data() })); }),
    saveTeamMember: firebaseAdminProcedure.input(z.object({ email: z.string().email().max(320), name: z.string().trim().max(100).optional(), role: z.enum(["admin", "reception"]) }).strict()).mutation(async ({ input }) => { const email = input.email.toLowerCase(); await adminDb().collection("team").doc(email).set({ ...input, email, active: true, updatedAt: Timestamp.now() }, { merge: true }); return { success: true }; }),
    removeTeamMember: firebaseAdminProcedure.input(z.object({ email: z.string().email() }).strict()).mutation(async ({ input }) => { await adminDb().collection("team").doc(input.email.toLowerCase()).set({ active: false, updatedAt: Timestamp.now() }, { merge: true }); return { success: true }; }),
  }),
});

export type AppRouter = typeof appRouter;

import { NOT_ADMIN_ERR_MSG, UNAUTHED_ERR_MSG } from '@shared/const';
import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";

type StaffContext = TrpcContext & { firebaseActor: NonNullable<TrpcContext["firebaseActor"]> };

const t = initTRPC.context<TrpcContext>().create({ transformer: superjson });
export const router = t.router;
export const publicProcedure = t.procedure;

const requireUser = t.middleware(async ({ ctx, next }) => {
  if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  return next({ ctx: { ...ctx, user: ctx.user } });
});
export const protectedProcedure = t.procedure.use(requireUser);

const requireFirebaseStaff = t.middleware(async ({ ctx, next }) => {
  if (!ctx.firebaseActor) throw new TRPCError({ code: "UNAUTHORIZED", message: "Faça login com seu acesso de equipe." });
  return next({ ctx: { ...ctx, firebaseActor: ctx.firebaseActor } as StaffContext });
});
const requireFirebaseAdmin = t.middleware(async ({ ctx, next }) => {
  if (!ctx.firebaseActor) throw new TRPCError({ code: "UNAUTHORIZED", message: "Faça login com seu acesso de equipe." });
  if (ctx.firebaseActor.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
  return next({ ctx: { ...ctx, firebaseActor: ctx.firebaseActor } as StaffContext });
});
export const firebaseStaffProcedure = t.procedure.use(requireFirebaseStaff);
export const firebaseAdminProcedure = t.procedure.use(requireFirebaseAdmin);

export const adminProcedure = protectedProcedure;

import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { adminAuth, adminDb, firebaseAdminStatus } from "../firebaseAdmin";

export type FirebaseActor = {
  uid: string;
  email: string;
  name?: string;
  role: "admin" | "reception";
};

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
  firebaseActor: FirebaseActor | null;
};

async function authenticateFirebase(req: CreateExpressContextOptions["req"]): Promise<FirebaseActor | null> {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ") || !firebaseAdminStatus().ready) return null;
  try {
    const decoded = await adminAuth().verifyIdToken(header.slice("Bearer ".length));
    const email = decoded.email?.toLowerCase();
    if (!email) return null;
    const member = (await adminDb().collection("team").doc(email).get()).data();
    if (!member || member.active === false) return null;
    return { uid: decoded.uid, email, name: decoded.name, role: member.role === "admin" ? "admin" : "reception" };
  } catch (error) {
    console.warn("[Firebase Auth] Request rejected", error instanceof Error ? error.message : "unknown error");
    return null;
  }
}

export async function createContext(opts: CreateExpressContextOptions): Promise<TrpcContext> {
  let firebaseActor: FirebaseActor | null = null;
  try { firebaseActor = await authenticateFirebase(opts.req); } catch { firebaseActor = null; }
  return { req: opts.req, res: opts.res, user: null as User | null, firebaseActor };
}

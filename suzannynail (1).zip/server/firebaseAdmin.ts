import { cert, getApps, initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore } from "firebase-admin/firestore";

type FirebaseAdminCredentials = {
  projectId?: string;
  clientEmail?: string;
  privateKey?: string;
};

let initialized = false;
let lastConnectionCheck = 0;
let cachedConnectionStatus: { ready: boolean } | null = null;

function credentials(): FirebaseAdminCredentials {
  return {
    projectId: process.env.FIREBASE_PROJECT_ID ?? process.env.VITE_FIREBASE_PROJECT_ID,
    clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
    privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, "\n"),
  };
}

export function firebaseAdminStatus() {
  const values = credentials();
  return { ready: Boolean(values.projectId && values.clientEmail && values.privateKey) };
}

export async function firebaseServiceStatus() {
  if (!firebaseAdminStatus().ready) return { ready: false };
  if (cachedConnectionStatus && Date.now() - lastConnectionCheck < 30_000) {
    return cachedConnectionStatus;
  }

  try {
    await adminDb().collection("team").limit(1).get();
    cachedConnectionStatus = { ready: true };
  } catch {
    cachedConnectionStatus = { ready: false };
  }
  lastConnectionCheck = Date.now();
  return cachedConnectionStatus;
}

function ensureFirebaseAdmin() {
  if (initialized || getApps().length) {
    initialized = true;
    return;
  }
  const { projectId, clientEmail, privateKey } = credentials();
  if (!projectId || !clientEmail || !privateKey) {
    throw new Error("Firebase Admin não está configurado no ambiente.");
  }
  initializeApp({ credential: cert({ projectId, clientEmail, privateKey }) });
  initialized = true;
}

export function adminAuth() {
  ensureFirebaseAdmin();
  return getAuth();
}

export function adminDb() {
  ensureFirebaseAdmin();
  return getFirestore();
}
